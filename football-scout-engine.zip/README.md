# Football Scout Engine

Moteur GPU RunPod pour analyser une vidéo de match, suivre un joueur et estimer
ses touches de balle, son temps de possession et sa trajectoire.

## Entrée RunPod

```json
{
  "input": {
    "video_url": "https://adresse-temporaire-vers-le-match.mp4",
    "target": {"x": 0.5, "y": 0.5},
    "sample_fps": 5,
    "confidence": 0.25
  }
}
```

`target.x` et `target.y` correspondent à la position du joueur sur la première
image, entre 0 et 1. La distance réelle en mètres nécessitera ensuite une
calibration du terrain dans la plateforme.
